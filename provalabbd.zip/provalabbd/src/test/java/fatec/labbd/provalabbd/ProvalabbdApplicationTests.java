package fatec.labbd.provalabbd;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProvalabbdApplicationTests {

	@Test
	void contextLoads() {
	}

}
